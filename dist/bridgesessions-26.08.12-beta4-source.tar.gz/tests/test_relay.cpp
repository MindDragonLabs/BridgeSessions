// winsock2 must come BEFORE windows.h
#ifdef _WIN32
#define NOMINMAX
#include <winsock2.h>
#include <ws2tcpip.h>
#pragma comment(lib, "ws2_32.lib")
#endif

#include <catch2/catch_test_macros.hpp>
#include <catch2/catch_session.hpp>

#ifdef min
#undef min
#endif
#ifdef max
#undef max
#endif

#include "../bs-protocol.h"

#ifdef _WIN32
#define CLOSESOCK closesocket
struct WsaInit { WsaInit() { WSADATA d; WSAStartup(MAKEWORD(2,2), &d); } ~WsaInit() { WSACleanup(); } };
static WsaInit _wsa;
#endif

#include <thread>
#include <atomic>
#include <chrono>

#ifndef _WIN32
#include <unistd.h>
#include <cerrno>
#endif

using namespace bs::mesh;

// ── SimulatedConn — wraps a Conn for unit-testing message handlers ──
// Provides:
//   - conn struct the handlers can write to
//   - tracks what frames were "written" (for assertions)
//   - ssl pointer that won't be dereferenced by non-PTY handler paths
struct SimulatedConn {
    MeshController::Conn conn;
    std::vector<Message> sent_messages;  // messages written via "write_frame"

    SimulatedConn() {
        conn.peer_name = "test-peer";
        conn.peer_pubkey = "aabbccdd";
        conn.peer_addr = "127.0.0.1:9999";
        conn.ssl.reset(); // null SSL ptr — tests that hit write_frame will call(nullptr,...) 
        conn.sock_fd = INVALID_SOCKET;
        conn.last_pong = std::chrono::steady_clock::now();
        conn.attached_session = nullptr;
    }
};

// ── Helpers ──────────────────────────────────────────────────────────

// Build a minimal MeshConfig for testing
static MeshConfig make_test_config(const std::string& node_name) {
    MeshConfig c;
    c.node_name = node_name;
    c.listen_port = 19949;  // different from default to avoid conflicts
    c.gossip_interval_secs = 300;  // don't gossip during tests
    c.ping_interval_secs = 300;
    c.scrollback_lines = 100;
    return c;
}

// ── Helpers ─────────────────────────────────────────────────────────

#ifndef _WIN32
static std::string read_pty_output(Session& sess, uint32_t timeout_ms = 3000) {
    std::string result;
    auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(timeout_ms);
    while (std::chrono::steady_clock::now() < deadline) {
        char buf[4096];
        ssize_t n = ::read(sess.master_fd, buf, sizeof(buf));
        if (n > 0) {
            result.append(buf, static_cast<size_t>(n));
            continue;
        }
        if (n == 0) break;
        if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) {
            std::this_thread::sleep_for(std::chrono::milliseconds(20));
            continue;
        }
        break;
    }
    return result;
}
#endif

// ── Test 1: KeystrokeMsg → writes to PTY, verifies scrollback ─────
TEST_CASE("KeystrokeMsg writes to session PTY via handle_inbound_session", "[relay][keystroke]") {
    auto cfg = make_test_config("test-node-1");
    MeshController mc(cfg);

    auto* s = mc.sessions().attach("test-sess", cfg.default_shell, 80, 24, "xterm-256color");
    REQUIRE(s != nullptr);
    REQUIRE(s->is_valid());

    SimulatedConn sc;
    sc.conn.attached_session = s;

    // Send a unique marker command and verify it reaches the PTY output.
    const std::string marker = "BS_RELAY_MARKER_42";
    KeystrokeMsg ks;
    ks.data = "echo " + marker + "\r\n";
    Message msg = ks;
    mc.handle_inbound_session(sc.conn, msg);

    // Wait for the shell to echo/execute and capture output.
    std::this_thread::sleep_for(std::chrono::milliseconds(200));

#ifdef _WIN32
    DWORD bytes_avail = 0;
    if (PeekNamedPipe(s->master_fd, nullptr, 0, nullptr, &bytes_avail, nullptr) && bytes_avail > 0) {
        std::string buf(bytes_avail, '\0');
        DWORD bytes_read = 0;
        ReadFile(s->master_fd, &buf[0], bytes_avail, &bytes_read, nullptr);
        buf.resize(bytes_read);
        s->scrollback.write(std::string_view(buf));
    }
    auto sb = s->scrollback.snapshot();
    WARN("Windows scrollback size: " << sb.size());
    // ConPTY timing is variable; at minimum exercise the write path.
    REQUIRE(!ks.data.empty());
#else
    std::string output = read_pty_output(*s, 3000);
    s->scrollback.write(std::string_view(output));
    auto sb = s->scrollback.snapshot();
    std::string_view sb_view(sb.data(), sb.size());
    INFO("PTY output: [" << output << "]");
    REQUIRE(sb_view.find(marker) != std::string_view::npos);
#endif
}

// ── Test 2: AttachMsg → session created, attached_session set ────────
TEST_CASE("AttachMsg creates session and sets attached_session on conn", "[relay][attach]") {
    auto cfg = make_test_config("test-node-attach");
    const std::string profile_command = cfg.default_shell;
    cfg.default_shell = "definitely-not-the-profile-command";
    cfg.session_commands["my-shared-session"] = profile_command;
    MeshController mc(cfg);

    SimulatedConn sc;

    AttachMsg attach;
    attach.session_name = "my-shared-session";
    attach.cols = 120;
    attach.rows = 40;
    attach.term = "xterm-256color";

    Message msg = attach;

    // Call handler — this should create the session via SessionRegistry
    mc.handle_inbound_session(sc.conn, msg);

    // Verify attached_session is set
    REQUIRE(sc.conn.attached_session != nullptr);
    REQUIRE(sc.conn.attached_session->name == "my-shared-session");

    // Verify session exists in registry
    auto* s2 = mc.sessions().get("my-shared-session");
    REQUIRE(s2 != nullptr);
    REQUIRE(s2->name == "my-shared-session");
    REQUIRE(s2->command == profile_command);
    REQUIRE(s2->state == SessionState::Attached);

    // Verify peer pubkey tracked in peer_ids vector
    REQUIRE(!s2->peer_ids.empty());
    REQUIRE(s2->peer_ids[0] == "aabbccdd");
}

// ── Test 3: ResizeMsg → resize_pty called ───────────────────────────
TEST_CASE("ResizeMsg resizes PTY via handle_inbound_session", "[relay][resize]") {
    auto cfg = make_test_config("test-node-resize");
    MeshController mc(cfg);

    auto* s = mc.sessions().attach("resize-test", cfg.default_shell, 80, 24, "xterm-256color");
    REQUIRE(s != nullptr);
    REQUIRE(s->is_valid());

    SimulatedConn sc;
    sc.conn.attached_session = s;

    ResizeMsg resize;
    resize.cols = 132;
    resize.rows = 43;

    Message msg = resize;

    // Call handler
    mc.handle_inbound_session(sc.conn, msg);

#ifdef _WIN32
    // ResizePseudoConsole has no public size getter; exercising it without error
    // is the available contract on Windows.
    REQUIRE(true);
#else
    winsize ws{};
    REQUIRE(::ioctl(s->master_fd, TIOCGWINSZ, &ws) == 0);
    REQUIRE(ws.ws_col == 132);
    REQUIRE(ws.ws_row == 43);
#endif
}

// ── Test 4: DetachMsg → session detached, attached_session cleared ──
TEST_CASE("DetachMsg detaches session and clears attached_session", "[relay][detach]") {
    auto cfg = make_test_config("test-node-detach");
    MeshController mc(cfg);

    auto* s = mc.sessions().attach("detach-test", cfg.default_shell, 80, 24, "xterm-256color");
    REQUIRE(s != nullptr);

    SimulatedConn sc;
    sc.conn.attached_session = s;

    DetachMsg detach;

    Message msg = detach;

    mc.handle_inbound_session(sc.conn, msg);

    // attached_session should be cleared
    REQUIRE(sc.conn.attached_session == nullptr);

    // The session should now be in Detached state
    auto* s2 = mc.sessions().get("detach-test");
    REQUIRE(s2 != nullptr);
    REQUIRE(s2->state == SessionState::Detached);
}

// ── Test 5: SignalMsg → sends signal to child process ───────────────
TEST_CASE("SignalMsg sends CtrlC to child process", "[relay][signal]") {
    auto cfg = make_test_config("test-node-signal");
    MeshController mc(cfg);

    auto* s = mc.sessions().attach("signal-test", cfg.default_shell, 80, 24, "xterm-256color");
    REQUIRE(s != nullptr);
    REQUIRE(s->is_valid());

    SimulatedConn sc;
    sc.conn.attached_session = s;

    SignalMsg sig;
    sig.signal = SignalMsg::SignalType::CtrlC;

    Message msg = sig;

    // Should not crash
    mc.handle_inbound_session(sc.conn, msg);

    REQUIRE(true);
}

TEST_CASE("Restart signal preserves replacement command and generation",
          "[relay][signal][restart]") {
    auto cfg = make_test_config("test-node-restart");
    MeshController mc(cfg);

#ifdef _WIN32
    const std::string initial = "cmd.exe";
    const std::string replacement = "cmd.exe /Q";
#else
    const std::string initial = "sleep 30";
    const std::string replacement = "sleep 31";
#endif

    auto* s = mc.sessions().attach("restart-test", initial, 80, 24,
                                   "xterm-256color");
    REQUIRE(s != nullptr);
    REQUIRE(s->is_valid());
    const uint64_t old_generation = s->generation;

    SimulatedConn sc;
    sc.conn.attached_session = s;
    SignalMsg sig;
    sig.signal = SignalMsg::SignalType::Restart;
    sig.process = replacement;
    Message msg = sig;

    mc.handle_inbound_session(sc.conn, msg);

    const std::string expected_replacement = prepare_session_command(
        {replacement, SessionCommandSource::ClientOverride});
    REQUIRE(s->is_valid());
    REQUIRE(s->generation > old_generation);
    REQUIRE(s->command == expected_replacement);
}

// ── Test 6: pty_output_poller exercises the poll path ─────────────────
TEST_CASE("pty_output_poller runs without crash", "[relay][output_poller]") {
    auto cfg = make_test_config("test-node-poller");
    MeshController mc(cfg);

    auto* s = mc.sessions().attach("poll-test", cfg.default_shell, 80, 24, "xterm-256color");
    REQUIRE(s != nullptr);

    // We need a conn in the conns_ vector with attached_session, but since
    // conns_ is private and we can't easily add to it without going through
    // the full TLS flow, test that the public methods work individually.
    //
    // pty_output_poller accesses conns_ privately, so we test the primitives
    // it uses (handle_inbound_session, write_all, scan_osc52) instead.
    //
    // Verify handle_inbound_session properly rejects messages without
    // attached_session:
    SimulatedConn sc;
    // sc.conn.attached_session is nullptr

    KeystrokeMsg ks;
    ks.data = "dir\r\n";
    Message msg = ks;

    // Should be a no-op (no crash)
    mc.handle_inbound_session(sc.conn, msg);

    REQUIRE(true);
}

// ── Test 7: ClipboardMsg via handle_inbound_session ─────────────────
TEST_CASE("ClipboardMsg writes bracketed paste to PTY", "[relay][clipboard]") {
    auto cfg = make_test_config("test-node-clip");
    MeshController mc(cfg);

    auto* s = mc.sessions().attach("clip-test", cfg.default_shell, 80, 24, "xterm-256color");
    REQUIRE(s != nullptr);
    REQUIRE(s->is_valid());

    SimulatedConn sc;
    sc.conn.attached_session = s;

    ClipboardMsg cb;
    cb.text = "hello clipboard";
    cb.hash = sha256_hex(cb.text);

    Message msg = cb;

    // Should write ESC[200~hello clipboardESC[201~ to PTY without crashing
    mc.handle_inbound_session(sc.conn, msg);

    REQUIRE(true);
}

// ── Test 8: Common message handlers ──────────────────────────────────
TEST_CASE("common_message_handler handles ScrollbackMsg", "[relay][common]") {
    auto cfg = make_test_config("test-node-common");
    MeshController mc(cfg);

    SimulatedConn sc;

    ScrollbackMsg sb;
    sb.data = "=== scrollback content ===\nline 2\nline 3\n";
    sb.total_lines = 3;
    sb.chunk_index = 0;

    Message msg = sb;

    // Should write to stdout (captured by test harness) without crash
    mc.common_message_handler(sc.conn, msg);

    REQUIRE(true);
}

TEST_CASE("common_message_handler handles SessionListMsg", "[relay][common]") {
    auto cfg = make_test_config("test-node-common");
    MeshController mc(cfg);

    SimulatedConn sc;

    SessionListMsg sl;
    sl.sessions.push_back({"sess1", "attached", 42});
    sl.sessions.push_back({"sess2", "detached", 360});

    Message msg = sl;

    // Should format and print to stdout
    mc.common_message_handler(sc.conn, msg);

    REQUIRE(true);
}

TEST_CASE("common_message_handler handles PingMsg", "[relay][common]") {
    auto cfg = make_test_config("test-node-common");
    MeshController mc(cfg);

    SimulatedConn sc;

    Message msg = PingMsg{};

    // This will try to write_frame with null SSL, should be caught
    // and not crash
    REQUIRE_NOTHROW(mc.common_message_handler(sc.conn, msg));
}

// ── Main ─────────────────────────────────────────────────────────────
int main(int argc, char* argv[]) {
    return Catch::Session().run(argc, argv);
}
